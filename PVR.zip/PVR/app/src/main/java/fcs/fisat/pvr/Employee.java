package fcs.fisat.pvr;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Employee extends AppCompatActivity {
    Register Rb;
    EditText e1,e2,e3,e4;
    Button register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.employee);
        Rb = new Register(this);

        e1 = (EditText)findViewById(R.id.name);
        e2 = (EditText)findViewById(R.id.email);
        e3 = (EditText)findViewById(R.id.pass);
        e4 = (EditText)findViewById(R.id.cpass);
        register = (Button)findViewById(R.id.button);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s4 = e1.getText().toString();
                String s1 = e2.getText().toString();
                String s2 = e3.getText().toString();
                String s3 = e4.getText().toString();
                if (s1.equals("")||s2.equals("")||s3.equals("")){
                    Toast.makeText(getApplicationContext(),"Enter Valid Inputs",Toast.LENGTH_SHORT).show();
                }
                else{
                    if (s2.equals(s3)){
                        Boolean chkemail = Rb.chkemail(s1);
                        if (chkemail){
                            Boolean insert = Rb.insert(s4,s1,s2);
                            if (insert){
                                Toast.makeText(getApplicationContext(),"Registered Successfully",Toast.LENGTH_SHORT).show();

                                Intent intent = new Intent(Employee.this,MainActivity.class);
                                startActivity(intent);
                            }

                        }
                        else{
                            Toast.makeText(getApplicationContext(),"Email Already exists",Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }
}
