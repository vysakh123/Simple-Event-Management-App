package fcs.fisat.pvr;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    Register rb;
    Button Elogin;
    EditText e2,e3;
    Button login;
    Button Signup;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rb = new Register(this);
        e2 = (EditText)findViewById(R.id.email);
        e3 = (EditText)findViewById(R.id.pass);
        Elogin = (Button)findViewById(R.id.button3);
        Signup = (Button)findViewById(R.id.button2);
        login = (Button)findViewById(R.id.button4);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = e2.getText().toString();
                String password = e3.getText().toString();
                Boolean emailpassword = rb.emailpassword(email,password);
                if (emailpassword){
                    Toast.makeText(getApplicationContext(),"Login Successful",Toast.LENGTH_SHORT).show();
                    Intent login = new Intent(MainActivity.this,Event.class);
                    startActivity(login);
                }

            }
        });

        Elogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = e2.getText().toString();
                String password = e3.getText().toString();
                if(email.equals("admin@pvr.com") && password.equals("admin123")) {
                    Toast.makeText(getApplicationContext(), "Succefully Logged In", Toast.LENGTH_SHORT).show();
                    Intent access = new Intent(MainActivity.this,Event.class);
                    startActivity(access);

                }
                else
                    Toast.makeText(getApplicationContext(),"Incorrect Employee credentials",Toast.LENGTH_SHORT).show();

            }
        });
        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signup = new Intent(MainActivity.this,Employee.class);
                startActivity(signup);
            }
        });



    }
}
