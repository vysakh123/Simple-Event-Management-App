package fcs.fisat.pvr;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Register extends SQLiteOpenHelper {
    public Register(@Nullable Context context) {
        super(context, "Register.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE usertable(NAME TEXT,EMAIL TEXT PRIMARY KEY,PASSWORD TEXT )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS usertable");

    }
    public boolean insert( String Name,String email,String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("Name",Name);
        contentValues.put("email",email);
        contentValues.put("password",password);
        long ins = sqLiteDatabase.insert("usertable",null,contentValues);
        if (ins==-1) return false;
        else return true;

    }
    public Boolean chkemail(String email){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM USERTABLE WHERE email=?",new String[]{email});
        if (cursor.getCount()>0) return false;
        else return true;

    }
    public Boolean emailpassword(String email,String password){
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("SELECT * FROM usertable where email=? and password=?",new String[]{email,password});
        if (cursor.getCount()>0)return true;
        else return false;
    }
    public Cursor getAllDatauser() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor resu = db.rawQuery("select * from usertable",null);
        return resu;
    }
}
